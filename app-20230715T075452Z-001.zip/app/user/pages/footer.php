<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Versi</b> 1.0
    </div>
    <strong>Hak Cipta &copy; <?= date('Y'); ?>. Fatiha & Syifa Team</strong> Perpustakaan Digital Informatika.
</footer>